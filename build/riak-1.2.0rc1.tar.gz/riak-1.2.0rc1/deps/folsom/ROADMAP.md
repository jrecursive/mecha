### Roadmap

* Tag based query API
* Metric metadata
* Various API features (raw histogram values,  multiple metric aggregates)
* Better statistical functions test coverage
* Sampling functions test coverage
* More production testing
* Regex history querying
* Customizable geometric mean zero value substitution value
