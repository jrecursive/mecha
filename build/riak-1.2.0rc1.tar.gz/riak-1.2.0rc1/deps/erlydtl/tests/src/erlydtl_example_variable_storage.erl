-module(erlydtl_example_variable_storage, [SomeVar]).
-compile(export_all).

some_var() ->
    SomeVar.
